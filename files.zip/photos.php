<?php
header('Content-Type: application/json');
header('Cache-Control: no-cache');

$uploadDir = __DIR__ . '/uploads/';
$extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'heic', 'heif'];

$files = [];
foreach (glob($uploadDir . '*') as $path) {
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    if (in_array($ext, $extensions)) {
        $files[] = [
            'name' => basename($path),
            'time' => filemtime($path),
        ];
    }
}

// Neueste zuerst
usort($files, fn($a, $b) => $b['time'] - $a['time']);

echo json_encode(array_column($files, 'name'));
